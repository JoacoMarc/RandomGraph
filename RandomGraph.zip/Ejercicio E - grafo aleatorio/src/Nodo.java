
public interface Nodo {
    int obtenerId();
    double obtenerProbabilidad();
    void establecerProbabilidad(double probabilidad);
}