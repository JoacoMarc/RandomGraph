import java.util.List;

public interface InterfazArbolBinario {
    void insertar(Nodo nodo);
    Nodo buscar(int id);
    List<Nodo> enOrden();


}
